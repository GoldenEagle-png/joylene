import tkinter as tk
from tkinter import messagebox
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import random
import joblib
import matplotlib.dates as mdates
import numpy as np

# Load the model
model = joblib.load('solar_energy_model.pkl')

# Placeholder for energy and workload data
solar_energy_data = []
data_center_energy_data = []

# Initialize the Tkinter window
root = tk.Tk()
root.title("Solar Energy Monitoring System")
root.geometry("1000x800")

# Manually define the data from the image
energy_metrics = {
    "Average Daily Consumption": 500,
    "Peak Consumption": 700,
    "Off-Peak Consumption": 300,
    "Real-Time Consumption": 550,
    "Minimum Consumption": 200,
    "Nighttime Consumption": 250,
    "Weekend Consumption": 450
}

# Functions for UI elements
def monitor_energy():
    solar_energy = random.uniform(0, 100)  # Simulate solar energy generation
    data_center_energy = random.uniform(50, 150)  # Simulate data center consumption
    
    solar_energy_data.append(solar_energy)
    data_center_energy_data.append(data_center_energy)
    
    lbl_solar_value.config(text=f"{solar_energy:.2f} kWh")
    lbl_data_center_value.config(text=f"{data_center_energy:.2f} kWh")
    
    root.after(1000, monitor_energy)  

def schedule_workload():
    energy_available = sum(solar_energy_data[-10:])  
    energy_required = sum(data_center_energy_data[-10:])
    
    if energy_available > energy_required:
        lbl_schedule_value.config(text="Distribute Workload Normally")
    else:
        lbl_schedule_value.config(text="Reduce Workload to Save Energy")
        messagebox.showinfo("Workload Management", "Switching Other Tasks to reduce workload, consider switching alternative energy sources.")

def predict_energy_and_schedule_tasks():
    start_hour = 6
    end_hour = 18
    interval = 5  
    minutes = [start_hour * 60 + i * interval for i in range((end_hour - start_hour) * (60 // interval))]

    current_date = datetime.now().date()
    features = pd.DataFrame({'date': [current_date] * len(minutes)})
    features['hour'] = [minute // 60 for minute in minutes]
    features['minute'] = [minute % 60 for minute in minutes]
    features['day_of_year'] = [current_date.timetuple().tm_yday] * len(minutes)
    features['month'] = [current_date.month] * len(minutes)
    features['temperature'] = [random.uniform(10, 40) for _ in range(len(minutes))]
    features['cloud_cover'] = [random.uniform(0, 100) for _ in range(len(minutes))]

    predictions = model.predict(features[['hour', 'day_of_year', 'month', 'temperature', 'cloud_cover']])

    def apply_random_decay(predictions, start_hour=12, end_hour=18, final_value=50):
        decay_predictions = predictions.copy()
        hours_range = range(start_hour, end_hour + 1)
        decay_factors = np.linspace(1, final_value / max(predictions), len(hours_range))

        for i in range(len(predictions)):
            hour = features['hour'][i]
            if hour >= start_hour:
                decay_index = hour - start_hour
                random_factor = random.uniform(0.8, 1.2)
                decay_predictions[i] *= decay_factors[decay_index] * random_factor
                decay_predictions[i] = max(final_value, decay_predictions[i])
        return decay_predictions

    predictions = apply_random_decay(predictions)

    server_tasks = ['Database Backup', 'Software Updates', 'Data Migration', 'Security Patching', 'Log Rotation', 'Performance Monitoring', 'Server Maintenance', 'Backup Verification', 'Resource Allocation', 'Load Balancing']
    
    total_energy = sum(predictions)
    required_energy = sum(data_center_energy_data[-len(minutes):])
    closed_tasks = []
    if total_energy < required_energy:
        closed_tasks = server_tasks[:len(server_tasks)//2]

    times = [datetime.combine(current_date, datetime.min.time()) + timedelta(minutes=minute) for minute in minutes]

    plt.ion()  
    fig, ax = plt.subplots(figsize=(12, 8))  

    def update_plot():
        ax.clear()  

        num_tasks = len(server_tasks)
        for i, task in enumerate(server_tasks):
            if task in closed_tasks:
                continue  

            task_times = times[i::num_tasks]
            task_predictions = predictions[i::num_tasks]

            ax.plot(task_times, task_predictions, label=task)

        ax.set_xlabel('Time of the Day')
        ax.set_ylabel('Predicted Solar Energy (kWh)')
        ax.set_title('Predicted Workload Schedule for Ministry Of ICT Data Center')

        ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=60))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        fig.autofmt_xdate()  

        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')  
        fig.subplots_adjust(right=0.75)  

        plt.draw()  
        plt.pause(0.1)  

    update_plot()  
    root.after(10000, update_plot)  

# UI Layout
lbl_solar = tk.Label(root, text="Solar Energy Generation:", font=("Arial", 14))
lbl_solar.grid(row=0, column=0, padx=10, pady=10)
lbl_solar_value = tk.Label(root, text="0 kWh", font=("Arial", 14))
lbl_solar_value.grid(row=0, column=1, padx=10, pady=10)

lbl_data_center = tk.Label(root, text="Data Center Energy Consumption:", font=("Arial", 14))
lbl_data_center.grid(row=1, column=0, padx=10, pady=10)
lbl_data_center_value = tk.Label(root, text="0 kWh", font=("Arial", 14))
lbl_data_center_value.grid(row=1, column=1, padx=10, pady=10)

lbl_schedule = tk.Label(root, text="Workload Schedule:", font=("Arial", 14))
lbl_schedule.grid(row=2, column=0, padx=10, pady=10)
lbl_schedule_value = tk.Label(root, text="Monitoring...", font=("Arial", 14))
lbl_schedule_value.grid(row=2, column=1, padx=10, pady=10)

# Add energy metrics to the UI
lbl_avg_daily = tk.Label(root, text=f"Avg Daily Consumption: {energy_metrics['Average Daily Consumption']} kWh", font=("Arial", 14))
lbl_avg_daily.grid(row=3, column=0, padx=10, pady=10)

lbl_peak = tk.Label(root, text=f"Peak Consumption: {energy_metrics['Peak Consumption']} kWh", font=("Arial", 14))
lbl_peak.grid(row=4, column=0, padx=10, pady=10)

lbl_off_peak = tk.Label(root, text=f"Off-Peak Consumption: {energy_metrics['Off-Peak Consumption']} kWh", font=("Arial", 14))
lbl_off_peak.grid(row=5, column=0, padx=10, pady=10)

lbl_real_time = tk.Label(root, text=f"Real-Time Consumption: {energy_metrics['Real-Time Consumption']} kWh", font=("Arial", 14))
lbl_real_time.grid(row=6, column=0, padx=10, pady=10)

lbl_min = tk.Label(root, text=f"Min Consumption: {energy_metrics['Minimum Consumption']} kWh", font=("Arial", 14))
lbl_min.grid(row=7, column=0, padx=10, pady=10)

lbl_night = tk.Label(root, text=f"Nighttime Consumption: {energy_metrics['Nighttime Consumption']} kWh", font=("Arial", 14))
lbl_night.grid(row=8, column=0, padx=10, pady=10)

lbl_weekend = tk.Label(root, text=f"Weekend Consumption: {energy_metrics['Weekend Consumption']} kWh", font=("Arial", 14))
lbl_weekend.grid(row=9, column=0, padx=10, pady=10)

btn_predict = tk.Button(root, text="Predict Energy and Schedule Tasks", command=predict_energy_and_schedule_tasks, font=("Arial", 14))
btn_predict.grid(row=10, column=0, padx=10, pady=10)

# Start monitoring
monitor_energy()
root.after(10000, schedule_workload)  # Check scheduling every 10 seconds

# Run the Tkinter event loop
root.mainloop()
