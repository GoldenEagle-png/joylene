import tkinter as tk
from tkinter import ttk
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import time  # To get the current Unix timestamp

# Sample historical solar energy data (in hours and minutes)
historical_hours = np.array([0, 24, 48, 72, 96, 120, 144, 168, 192, 216])  # Sample timestamps (in hours)
historical_minutes = historical_hours * 60  # Convert hours to minutes for prediction
historical_energy = np.array([20, 25, 30, 35, 40, 45, 50, 55, 60, 65])  # Sample energy values (kW/m^2)

# Fit a linear regression model to predict solar energy
regressor = LinearRegression()
regressor.fit(historical_minutes.reshape(-1, 1), historical_energy)

def predict_solar_energy(timestamp):
    # Predict solar energy for the given timestamp using the trained model
    predicted_energy = regressor.predict([[timestamp]])[0]
    
    # Ensure the predicted energy is within realistic bounds
    predicted_energy = max(0, min(predicted_energy, 100))  # Limit to range [0, 100] kW/m^2
    
    return predicted_energy

def optimize_workload(solar_energy):
    # Define thresholds for solar energy levels (adjust as needed)
    high_threshold = 70  # High solar energy threshold (% of maximum capacity)
    low_threshold = 30   # Low solar energy threshold (% of maximum capacity)
    
    # Get current workload status (replace with actual workload data)
    current_workload = get_current_workload()  
    
    # Check solar energy level and adjust workload accordingly
    if (solar_energy >= high_threshold):
        # High solar energy: Shift workload to maximize utilization
        optimized_workload = shift_workload(current_workload, "maximize")
    elif (solar_energy <= low_threshold):
        # Low solar energy: Shift workload to minimize power consumption
        optimized_workload = shift_workload(current_workload, "minimize")
    else:
        # Moderate solar energy: Maintain current workload distribution
        optimized_workload = current_workload
    
    # Return the optimized workload
    return optimized_workload

def get_current_workload():
    # Placeholder function to retrieve current workload data (replace with actual implementation)
    current_workload = {f'Task{i}': i*10 for i in range(1, 16)}  # Example workload data with 15 tasks
    return current_workload

def shift_workload(workload, strategy):
    # Placeholder implementation of round-robin load balancing
    servers = ['Utande Data Center', 'National Data Center']  # List of servers
    server_index = 0  # Index to track the current server
    
    optimized_workload = {}
    for task, load in workload.items():
        optimized_workload[task] = servers[server_index]  # Assign tasks to servers in a round-robin manner
        server_index = (server_index + 1) % len(servers)  # Move to the next server
    
    return optimized_workload

def switch_to_alternative_energy(solar_energy, current_workload):
    switch_threshold = 20  # Solar energy threshold (% of maximum capacity)
    
    if (solar_energy < switch_threshold):
        print("Switching to alternative energy sources due to insufficient solar power.")
        alternative_workload = redistribute_workload(current_workload)
        return alternative_workload
    else:
        return current_workload

def redistribute_workload(current_workload):
    servers = ['Utande Data Center', 'National Data Center']  # List of servers
    num_servers = len(servers)
    optimized_workload = {}
    
    for i, (task, load) in enumerate(current_workload.items()):
        server_index = i % num_servers  # Distribute tasks evenly across servers
        optimized_workload[task] = servers[server_index]
    
    return optimized_workload

def calculate_and_update():
    try:
        timestamp_str = timestamp_entry.get()
        if timestamp_str:
            # Convert timestamp to minutes
            timestamp_hours, timestamp_minutes = map(float, timestamp_str.split(":"))
            timestamp = timestamp_hours * 60 + timestamp_minutes
        else:
            # Get the current Unix timestamp and convert to minutes
            timestamp = time.time() / 60  # Convert seconds to minutes
        solar_energy = float(solar_energy_entry.get())
    except ValueError:
        result_label.config(text="Invalid input! Please enter numeric values.")
        return
    
    predicted_energy = predict_solar_energy(timestamp)
    optimized_workload = optimize_workload(solar_energy)
    alternative_workload = switch_to_alternative_energy(solar_energy, optimized_workload)
    
    workload_display = "\n".join([f"{task}: {server}" for task, server in alternative_workload.items()])
    
    if solar_energy < 20:
        result_label.config(text="Solar energy is insufficient. Workload has been optimized for alternative energy sources.")
    else:
        result_label.config(text=f"Solar Energy Availability: {solar_energy:.2f} kW/m^2\n\nWorkload Distribution:\n{workload_display}")
    
    plot_graph(timestamp, solar_energy, predicted_energy, alternative_workload)

def plot_graph(timestamp, solar_energy, predicted_energy, alternative_workload):
    # Clear the previous plot
    for widget in graph_frame.winfo_children():
        widget.destroy()

    # Create a new figure
    fig, ax = plt.subplots(figsize=(8, 6))

    # Plot the historical data
    ax.scatter(historical_minutes, historical_energy, color='blue', label='Historical Data')
    for i, txt in enumerate(historical_energy):
        ax.annotate(f'{txt:.2f}', (historical_minutes[i], historical_energy[i]), textcoords="offset points", xytext=(0, 10), ha='center')

    # Plot the linear regression line
    predicted_energy_all = regressor.predict(historical_minutes.reshape(-1, 1))
    ax.plot(historical_minutes, predicted_energy_all, color='red', label='Regression Line')
    for i, txt in enumerate(predicted_energy_all):
        ax.annotate(f'{txt:.2f}', (historical_minutes[i], predicted_energy_all[i]), textcoords="offset points", xytext=(0, -15), ha='center')

    # Highlight the predicted solar energy input and the user-provided solar energy
    ax.scatter([timestamp], [predicted_energy], color='green', label='Predicted Energy')
    ax.annotate(f'{predicted_energy:.2f}', (timestamp, predicted_energy), textcoords="offset points", xytext=(0, 10), ha='center')

    ax.scatter([timestamp], [solar_energy], color='orange', label='Provided Solar Energy')
    ax.annotate(f'{solar_energy:.2f}', (timestamp, solar_energy), textcoords="offset points", xytext=(0, -15), ha='center')

    # Plot workload distribution for each data center
    utande_tasks = [task for task, server in alternative_workload.items() if server == 'Utande Data Center']
    national_tasks = [task for task, server in alternative_workload.items() if server == 'National Data Center']
    
    utande_energy = [10 * int(task.split('Task')[1]) for task in utande_tasks]
    national_energy = [10 * int(task.split('Task')[1]) for task in national_tasks]
    
    ax.scatter([timestamp]*len(utande_tasks), utande_energy, color='purple', label='Utande Data Center')
    ax.scatter([timestamp]*len(national_tasks), national_energy, color='cyan', label='National Data Center')
    
    # Customize the plot
    ax.set_xlabel('Time (minutes)')
    ax.set_ylabel('Solar Energy (kW/m^2)')
    ax.set_title('Solar Energy Prediction and Workload Distribution')
    ax.legend()

    # Add the plot to the Tkinter GUI
    canvas = FigureCanvasTkAgg(fig, master=graph_frame)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

# Initialize GUI
root = tk.Tk()
root.title("Solar Energy-Based Workload Optimization")

# Create GUI components using ttk for a more professional look
style = ttk.Style(root)
style.theme_use("clam")  # You can choose different themes like 'clam', 'alt', 'default', etc.

timestamp_label = ttk.Label(root, text="Enter Timestamp (HH:MM or leave blank for current time):")
timestamp_entry = ttk.Entry(root)
solar_energy_label = ttk.Label(root, text="Enter Solar Energy (kW/m^2):")
solar_energy_entry = ttk.Entry(root)
calculate_button = ttk.Button(root, text="Calculate", command=calculate_and_update)
result_label = ttk.Label(root, text="", wraplength=400, justify=tk.LEFT)

# Arrange GUI components using grid layout
timestamp_label.grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
timestamp_entry.grid(row=0, column=1, padx=10, pady=10, sticky=tk.EW)
solar_energy_label.grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)
solar_energy_entry.grid(row=1, column=1, padx=10, pady=10, sticky=tk.EW)
calculate_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)
result_label.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky=tk.W)

# Create a frame for the graph
graph_frame = ttk.Frame(root)
graph_frame.grid(row=4, column=0, columnspan=2, padx=10, pady=10, sticky=tk.NSEW)

# Configure the grid to expand properly
root.grid_columnconfigure(0, weight=1)
root.grid_rowconfigure(4, weight=1)

# Expand entry widgets to fill the column
root.grid_columnconfigure(1, weight=1)

# Start GUI event loop
root.mainloop()
