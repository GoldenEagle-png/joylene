import tkinter as tk
import pandas as pd
import joblib
from datetime import datetime, timedelta
import random
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# Load the model
model = joblib.load('solar_energy_model.pkl')

# Initialize Tkinter window
root = tk.Tk()
root.title("Solar Energy Monitoring System")
root.geometry("1000x800")

def predict_energy_and_schedule_tasks():
    # Define daytime range from 6 AM to 6 PM
    start_hour = 6
    end_hour = 18
    interval = 5  # 5-minute interval
    minutes = [start_hour * 60 + i * interval for i in range((end_hour - start_hour) * (60 // interval))]

    # Predict solar energy for the specified range
    current_date = datetime.now().date()
    features = pd.DataFrame({'date': [current_date] * len(minutes)})
    features['hour'] = [minute // 60 for minute in minutes]
    features['minute'] = [minute % 60 for minute in minutes]
    features['day_of_year'] = [current_date.timetuple().tm_yday] * len(minutes)
    features['temperature'] = [random.uniform(10, 40) for _ in range(len(minutes))]
    features['cloud_cover'] = [random.uniform(0, 100) for _ in range(len(minutes))]

    predictions = model.predict(features[['hour', 'day_of_year', 'temperature', 'cloud_cover']])

    # Create a time array for the x-axis within the 5-minute interval
    times = [datetime.combine(current_date, datetime.min.time()) + timedelta(minutes=minute) for minute in minutes]

    # Plot predicted solar energy
    plt.ion()  # Turn on interactive mode for real-time updating
    fig, ax = plt.subplots(figsize=(12, 8))  # Increase figure size

    ax.plot(times, predictions, label='Predicted Solar Energy (kWh)')
    ax.set_xlabel('Time of the Day')
    ax.set_ylabel('Predicted Solar Energy (kWh)')
    ax.set_title('Predicted Solar Energy Generation for Today')
    ax.legend()

    # Add more ticks on the x-axis for better readability
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))

    plt.grid(True)
    plt.draw()

    plt.show()

btn_predict = tk.Button(root, text="Predict Energy and Schedule Tasks", command=predict_energy_and_schedule_tasks)
btn_predict.pack()

root.mainloop()
