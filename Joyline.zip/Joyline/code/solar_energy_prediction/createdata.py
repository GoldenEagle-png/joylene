import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
import joblib

# Create synthetic dataset
def generate_synthetic_data(start_date, end_date, freq='H'):
    date_range = pd.date_range(start=start_date, end=end_date, freq=freq)
    data = []

    for date in date_range:
        hour = date.hour
        day_of_year = date.timetuple().tm_yday
        temperature = np.random.uniform(10, 40)
        cloud_cover = np.random.uniform(0, 100)
        
        # Generate solar energy data using a Gaussian function
        peak_time = 12  # Solar energy peaks at noon
        solar_energy = 50 * np.exp(-0.5 * ((hour - peak_time) / 3) ** 2)  # Normal distribution
        
        # Random noise for more realistic data
        solar_energy += np.random.normal(0, 3)
        
        data_center_energy = np.random.uniform(50, 150)
        
        data.append({
            'date': date,
            'hour': hour,
            'day_of_year': day_of_year,
            'temperature': temperature,
            'cloud_cover': cloud_cover,
            'solar_energy': solar_energy,
            'data_center_energy': data_center_energy
        })
    
    return pd.DataFrame(data)

# Generate synthetic data
start_date = datetime(2023, 1, 1)
end_date = datetime(2023, 12, 31)
data = generate_synthetic_data(start_date, end_date)

# Save to CSV
data.to_csv('synthetic_solar_data.csv', index=False)
