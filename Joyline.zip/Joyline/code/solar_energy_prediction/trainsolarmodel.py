import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import joblib

# Load data
data = pd.read_csv('synthetic_solar_data.csv')

# Features and target
features = data[['hour', 'day_of_year', 'temperature', 'cloud_cover']]
target = data['solar_energy']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Train the model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Print training score
train_score = model.score(X_train, y_train)
print(f"Training score: {train_score}")

# Print test score
test_score = model.score(X_test, y_test)
print(f"Test score: {test_score}")

# Save the model
joblib.dump(model, 'solar_energy_model.pkl')
