import tkinter as tk
from tkinter import ttk
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import time  # To get the current Unix timestamp

# Sample historical solar energy data (in hours and minutes)
historical_hours = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9,1,2,3,4,5,6,7,8,9])  # Sample timestamps (in hours)
historical_minutes = historical_hours * 3600  # Convert hours to minutes for prediction
historical_energy = np.array([20, 21, 10, 35, 20, 45, 30, 45, 60, 75,43,65,92,56,34,21, 10, 35, 20])  # Sample energy values (kW/m^2)

# Fit a linear regression model to predict solar energy
regressor = LinearRegression()
regressor.fit(historical_minutes.reshape(-1, 1), historical_energy)

def predict_solar_energy(timestamp):
    # Predict solar energy for the given timestamp using the trained model
    predicted_energy = regressor.predict([[timestamp]])[0]
    
    # Ensure the predicted energy is within realistic bounds
    predicted_energy = max(0, min(predicted_energy, 100))  # Limit to range [0, 100] kW/m^2
    
    return predicted_energy

def optimize_workload(solar_energy):
    # Define thresholds for solar energy levels (adjust as needed)
    high_threshold = 70  # High solar energy threshold (% of maximum capacity)
    low_threshold = 30   # Low solar energy threshold (% of maximum capacity)
    
    # Get current workload status (replace with actual workload data)
    current_workload = get_current_workload()  
    
    # Check solar energy level and adjust workload accordingly
    if (solar_energy >= high_threshold):
        # High solar energy: Shift workload to maximize utilization
        optimized_workload = shift_workload(current_workload, "maximize")
    elif (solar_energy <= low_threshold):
        # Low solar energy: Shift workload to minimize power consumption
        optimized_workload = shift_workload(current_workload, "minimize")
    else:
        # Moderate solar energy: Maintain current workload distribution
        optimized_workload = current_workload
    
    # Return the optimized workload
    return optimized_workload

def get_current_workload():
    # Placeholder function to retrieve current workload data (replace with actual implementation)
    current_workload = {f'Task{i}': i*10 for i in range(1, 11)}  # Example workload data with 300 tasks
    return current_workload

def shift_workload(workload, strategy):
    # Placeholder implementation of round-robin load balancing
    servers = ['Utande Data Center', 'National Data Center']  # List of servers
    server_index = 0  # Index to track the current server
    
    optimized_workload = {}
    for task, load in workload.items():
        optimized_workload[task] = servers[server_index]  # Assign tasks to servers in a round-robin manner
        server_index = (server_index + 1) % len(servers)  # Move to the next server
    
    return optimized_workload

def switch_to_alternative_energy(solar_energy, current_workload):
    switch_threshold = 20  # Solar energy threshold (% of maximum capacity)
    
    if (solar_energy < switch_threshold):
        print("Switching to alternative energy sources due to insufficient solar power.")
        alternative_workload = redistribute_workload(current_workload)
        return alternative_workload
    else:
        return current_workload

def redistribute_workload(current_workload):
    servers = ['Utande Data Center', 'National Data Center']  # List of servers
    num_servers = len(servers)
    optimized_workload = {}
    
    for i, (task, load) in enumerate(current_workload.items()):
        server_index = i % num_servers  # Distribute tasks evenly across servers
        optimized_workload[task] = servers[server_index]
    
    return optimized_workload

def calculate_and_update():
    try:
        timestamp_str = timestamp_entry.get()
        if timestamp_str:
            # Convert timestamp to minutes
            timestamp_hours, timestamp_minutes = map(float, timestamp_str.split(":"))
            timestamp = timestamp_hours * 60 + timestamp_minutes
        else:
            # Get the current Unix timestamp and convert to minutes
            timestamp = time.time() / 60  # Convert seconds to minutes
        solar_energy = float(solar_energy_entry.get())
    except ValueError:
        result_label.config(text="Invalid input! Please enter numeric values.")
        return
    
    predicted_energy = predict_solar_energy(timestamp)
    optimized_workload = optimize_workload(solar_energy)
    alternative_workload = switch_to_alternative_energy(solar_energy, optimized_workload)
    
    workload_display = "\n".join([f"{task}: {server}" for task, server in alternative_workload.items()])
    
    if solar_energy < 20:
        result_label.config(text="Solar energy is insufficient. Workload has been optimized for alternative energy sources.")
    else:
        result_label.config(text=f"Solar Energy Availability: {solar_energy:.2f} kW/m^2")
    
    plot_graphs(timestamp, solar_energy, predicted_energy, alternative_workload)

def plot_graphs(timestamp, solar_energy, predicted_energy, alternative_workload):
    # Clear the previous plot
    for widget in graph_frame.winfo_children():
        widget.destroy()

    # Create a new figure with two subplots side by side
    fig, (ax_utande, ax_national) = plt.subplots(1, 2, figsize=(16, 6))

    # Plot the historical data on both subplots
    ax_utande.scatter(historical_minutes, historical_energy, color='blue', label='Tasks ')
    ax_national.scatter(historical_minutes, historical_energy, color='blue', label='Tasks')

    # Plot the linear regression line on both subplots
    predicted_energy_all = regressor.predict(historical_minutes.reshape(-1, 1))
    ax_utande.plot(historical_minutes, predicted_energy_all, color='red', label='Regression Line')
    ax_national.plot(historical_minutes, predicted_energy_all, color='red', label='Regression Line')

    # Highlight the predicted solar energy input and the user-provided solar energy on both subplots
    ax_utande.scatter([timestamp], [predicted_energy], color='green', label='Predicted Energy')
    ax_national.scatter([timestamp], [predicted_energy], color='green', label='Predicted Energy')

    ax_utande.scatter([timestamp], [solar_energy], color='orange', label='Provided Solar Energy')
    ax_national.scatter([timestamp], [solar_energy], color='orange', label='Provided Solar Energy')

    # Plot workload distribution for each data center
    utande_tasks = [task for task, server in alternative_workload.items() if server == 'Utande Data Center']
    national_tasks = [task for task, server in alternative_workload.items() if server == 'National Data Center']
    
    utande_energy = [10 * int(task.split('Task')[1]) for task in utande_tasks]
    national_energy = [10 * int(task.split('Task')[1]) for task in national_tasks]
    
    # Ensure at least 50 points for the workload scatter plot
    for _ in range(300 - len(utande_energy)):
        utande_energy.append(0)
        
    for _ in range(300 - len(national_energy)):
        national_energy.append(0)
    
    ax_utande.scatter([predicted_energy]*len(utande_energy), utande_energy, color='purple', label='Utande Data Center')
    ax_national.scatter([predicted_energy]*len(national_energy), national_energy, color='cyan', label='National Data Center')
    
    # Customize the plots
    ax_utande.set_xlabel('Time (minutes)')
    ax_utande.set_ylabel('Solar Energy (kW/m^2)')
    ax_utande.set_title('Utande Data Center Workload Distribution')
    ax_utande.legend()

    ax_national.set_xlabel('Time (minutes)')
    ax_national.set_ylabel('Solar Energy (kW/m^2)')
    ax_national.set_title('National Data Center Workload Distribution')
    ax_national.legend()

    # Add task labels to the plots
    for i, task in enumerate(utande_tasks):
        ax_utande.annotate(task, (timestamp, utande_energy[i]), textcoords="offset points", xytext=(0,10), ha='center', fontsize=8)

    for i, task in enumerate(national_tasks):
        ax_national.annotate(task, (timestamp, national_energy[i]), textcoords="offset points", xytext=(0,10), ha='center', fontsize=8)

    # Add the plots to the Tkinter GUI
    canvas = FigureCanvasTkAgg(fig, master=graph_frame)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

# Initialize GUI
root = tk.Tk()
root.title("Solar Energy-Based Workload Optimization")

# Create GUI components using ttk for a more professional look
style = ttk.Style(root)
style.theme_use("clam")  # You can choose different themes like 'clam', 'alt', 'default', etc.

timestamp_label = ttk.Label(root, text="Enter Timestamp (HH:MM):")
timestamp_label.pack(pady=5)

timestamp_entry = ttk.Entry(root)
timestamp_entry.pack(pady=5)

solar_energy_label = ttk.Label(root, text="Enter Solar Energy (kW/m^2):")
solar_energy_label.pack(pady=5)

solar_energy_entry = ttk.Entry(root)
solar_energy_entry.pack(pady=5)

calculate_button = ttk.Button(root, text="Calculate", command=calculate_and_update)
calculate_button.pack(pady=10)

result_label = ttk.Label(root, text="")
result_label.pack(pady=5)

graph_frame = ttk.Frame(root)
graph_frame.pack(fill=tk.BOTH, expand=True, pady=10)

root.mainloop()
