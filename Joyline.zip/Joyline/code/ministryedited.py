import tkinter as tk
from tkinter import messagebox
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import random
import joblib
import matplotlib.dates as mdates
import numpy as np

# Load the model
model = joblib.load('solar_energy_model.pkl')

# Placeholder for energy and workload data
solar_energy_data = []
data_center_energy_data = []

# Initialize the Tkinter window
root = tk.Tk()
root.title("Solar Energy Monitoring System")
root.geometry("1000x800")

# Functions for UI elements
def monitor_energy():
    # Placeholder for actual monitoring logic
    solar_energy = random.uniform(0, 100)  # Simulate solar energy generation
    data_center_energy = random.uniform(50, 150)  # Simulate data center consumption
    
    solar_energy_data.append(solar_energy)
    data_center_energy_data.append(data_center_energy)
    
    lbl_solar_value.config(text=f"{solar_energy:.2f} kWh")
    lbl_data_center_value.config(text=f"{data_center_energy:.2f} kWh")
    
    # Update every second
    root.after(1000, monitor_energy)  

def schedule_workload():
    energy_available = sum(solar_energy_data[-10:])  # Sum of last 10 entries
    energy_required = sum(data_center_energy_data[-10:])
    
    if energy_available > energy_required:
        # Distribute workload normally
        lbl_schedule_value.config(text="Distribute Workload Normally")
    else:
        # Reduce workload to save energy
        lbl_schedule_value.config(text="Reduce Workload to Save Energy")
        
        # Example: Switch to alternative energy sources during low solar power
        # Placeholder logic to switch to alternative energy sources
        # Example: Using battery backup or switching to grid power
        
        # Display a message to notify the user about switching to alternative energy sources
        messagebox.showinfo("Switch to Alternative Energy", "Switching to alternative energy sources.")

import numpy as np

def predict_energy_and_schedule_tasks():
    # Define daytime range from 6 AM to 6 PM
    start_hour = 6
    end_hour = 18
    interval = 5  # 5-minute interval
    minutes = [start_hour * 60 + i * interval for i in range((end_hour - start_hour) * (60 // interval))]

    # Predict solar energy for the specified range
    current_date = datetime.now().date()
    features = pd.DataFrame({'date': [current_date] * len(minutes)})
    features['hour'] = [minute // 60 for minute in minutes]
    features['minute'] = [minute % 60 for minute in minutes]
    features['day_of_year'] = [current_date.timetuple().tm_yday] * len(minutes)
    features['month'] = [current_date.month] * len(minutes)
    features['temperature'] = [random.uniform(10, 40) for _ in range(len(minutes))]
    features['cloud_cover'] = [random.uniform(0, 100) for _ in range(len(minutes))]

    predictions = model.predict(features[['hour', 'day_of_year', 'month', 'temperature', 'cloud_cover']])

    # Apply a random decay to reduce energy consumption to 50 kWh by 6 PM
    def apply_random_decay(predictions, start_hour=12, end_hour=18, final_value=50):
        decay_predictions = predictions.copy()
        hours_range = range(start_hour, end_hour + 1)
        decay_factors = np.linspace(1, final_value / max(predictions), len(hours_range))

        for i in range(len(predictions)):
            hour = features['hour'][i]
            if hour >= start_hour:
                decay_index = hour - start_hour
                random_factor = random.uniform(0.8, 1.2)  # Add randomness
                decay_predictions[i] *= decay_factors[decay_index] * random_factor
                decay_predictions[i] = max(final_value, decay_predictions[i])  # Ensure it doesn't go below final_value
        return decay_predictions

    predictions = apply_random_decay(predictions)

    # Generate a schedule of tasks based on energy availability
    server_tasks = ['Database Backup', 'Software Updates', 'Data Migration', 'Security Patching', 'Log Rotation', 'Performance Monitoring', 'Server Maintenance', 'Backup Verification', 'Resource Allocation', 'Load Balancing']
    
    # Calculate available energy
    total_energy = sum(predictions)
    required_energy = sum(data_center_energy_data[-len(minutes):])

    # Determine which tasks to close based on energy availability
    closed_tasks = []
    if total_energy < required_energy:
        closed_tasks = server_tasks[:len(server_tasks)//2]  # Close half of the tasks as an example

    # Create a time array for the x-axis within the 5-minute interval
    times = [datetime.combine(current_date, datetime.min.time()) + timedelta(minutes=minute) for minute in minutes]

    # Plot predicted solar energy
    plt.ion()  # Turn on interactive mode for real-time updating
    fig, ax = plt.subplots(figsize=(12, 8))  # Increase figure size

    def update_plot():
        ax.clear()  # Clear the current plot

        # Plot tasks on the x-axis
        num_tasks = len(server_tasks)
        for i, task in enumerate(server_tasks):
            if task in closed_tasks:
                continue  # Skip plotting tasks that are closed due to energy constraints

            task_times = times[i::num_tasks]
            task_predictions = predictions[i::num_tasks]

            ax.plot(task_times, task_predictions, label=task)

        ax.set_xlabel('Time of the Day')
        ax.set_ylabel('Predicted Solar Energy (kWh)')
        ax.set_title('Predicted Solar Energy for the Day with Task Schedule for Ministry Of ICT Data Center')

        # Formatting the x-axis to display time as HH:MM
        ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=60))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        fig.autofmt_xdate()  # Rotate date labels

        # Adjust the legend to avoid overlapping with the plot
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')  # Move the legend to the side
        fig.subplots_adjust(right=0.75)  # Adjust the right margin to make room for the legend

        plt.draw()  # Redraw the plot
        plt.pause(0.1)  # Pause briefly to allow the plot to update

    update_plot()  # Initial plot update
    root.after(10000, update_plot)  # Update the plot every 10 seconds

# UI Layout
lbl_solar = tk.Label(root, text="Solar Energy Generation:", font=("Arial", 14))
lbl_solar.grid(row=0, column=0, padx=10, pady=10)
lbl_solar_value = tk.Label(root, text="0 kWh", font=("Arial", 14))
lbl_solar_value.grid(row=0, column=1, padx=10, pady=10)

lbl_data_center = tk.Label(root, text="Data Center Energy Consumption:", font=("Arial", 14))
lbl_data_center.grid(row=1, column=0, padx=10, pady=10)
lbl_data_center_value = tk.Label(root, text="0 kWh", font=("Arial", 14))
lbl_data_center_value.grid(row=1, column=1, padx=10, pady=10)

lbl_schedule = tk.Label(root, text="Workload Schedule:", font=("Arial", 14))
lbl_schedule.grid(row=2, column=0, padx=10, pady=10)
lbl_schedule_value = tk.Label(root, text="Monitoring...", font=("Arial", 14))
lbl_schedule_value.grid(row=2, column=1, padx=10, pady=10)

btn_predict = tk.Button(root, text="Predict Energy and Schedule Tasks", command=predict_energy_and_schedule_tasks, font=("Arial", 14))
btn_predict.grid(row=3, column=0, padx=10, pady=10)

# Start monitoring
monitor_energy()
root.after(10000, schedule_workload)  # Check scheduling every 10 seconds

# Run the Tkinter event loop
root.mainloop()
