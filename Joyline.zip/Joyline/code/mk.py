import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import joblib

# Generate synthetic data
np.random.seed(0)

# Generate features
num_samples = 1000
hour = np.random.randint(0, 24, num_samples)
day_of_year = np.random.randint(1, 366, num_samples)
month = pd.to_datetime(day_of_year, format='%j').month
temperature = np.random.uniform(10, 40, num_samples)
cloud_cover = np.random.uniform(0, 100, num_samples)

# Generate target variable (solar energy generation)
solar_energy = (hour * 5) + (day_of_year / 10) + (temperature / 2) - (cloud_cover / 20) + np.random.normal(0, 5, num_samples)

# Create DataFrame
data = pd.DataFrame({
    'hour': hour,
    'day_of_year': day_of_year,
    'month': month,
    'temperature': temperature,
    'cloud_cover': cloud_cover,
    'solar_energy': solar_energy
})

# Split data into features and target variable
X = data.drop(columns=['solar_energy'])
y = data['solar_energy']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Random Forest model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate model
train_score = model.score(X_train, y_train)
test_score = model.score(X_test, y_test)
print(f"Training R^2 score: {train_score:.2f}")
print(f"Testing R^2 score: {test_score:.2f}")

# Save the model
joblib.dump(model, 'solar_energy_model.pkl')
